<?php $__env->startSection("content"); ?>
    <script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/manhua.js?ver=1.0"); ?>"></script>
    <section class="Hui-article-box">
        <div class="Hui-article">
            <input type="hidden" id="hid_tid" value="0" />
            <article class="cl pd-20">
                <div class="text-c">
                    <form id="frm_admin" action="/backend/manhua/manhualist" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <input type="text" class="input-text" style="width:250px" placeholder="输入漫画" id="seach_uname" name="searchword" value="">
                        <button type="submit" class="btn btn-success radius" id="btn_seach" name="btn_seach">
                            <i class="Hui-iconfont">&#xe665;</i> 搜
                        </button>
                    </form>
                </div>

                <div class="cl pd-5 bg-1 bk-gray mt-20">
                <span class="l">
                    <a href="javascript:;" id="btn_add_category" class="btn btn-primary radius" onclick="opennewmanhua();">
                        <i class="Hui-iconfont">&#xe600;</i> 添加漫画
                    </a>
                </span>
                </div>

                <div class="mt-20">
                    <table class="table table-border table-bordered table-hover table-bg table-sort">
                        <thead>
                        <tr class="text-c">
                            <th width="80">漫画ID</th>
                            <th width="100">漫画封面</th>
                            <th width="100">漫画名</th>
                            <th width="80">分类</th>
                            <th width="70">作者</th>
                            <th width="70">简介</th>
                            <th width="70">观看数</th>
                            <th width="70">完结/连载</th>
                            <th width="70">显示/不显示</th>
                            <th width="70">更新时间</th>
                            <th width="70">入库时间</th>
                            <th width="100">操作</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($datas as $data): ?>
                            <tr class="text-c">
                                <td><?php echo e($data['manhua_id']); ?></td>
                                <td><img src="<?php echo e($data['cover']); ?>" style="width:50px;" /></td>
                                <td><a href="/backend/manhua/chapterlist/<?php echo e($data['manhua_id']); ?>" style="color: red;" title="搜索<?php echo e($data['name']); ?>的章节"><?php echo e($data['name']); ?></a></td>
                                <td><?php echo e($data['c_name']); ?></td>
                                <td><?php echo e($data['author']); ?></td>
                                <td><?php echo e($data['intro']); ?></td>
                                <td><?php echo e($data['views']); ?></td>
                                <td><?php if($data['finish']==1): ?> 完结 <?php else: ?> 连载 <?php endif; ?></td>
                                <td><?php if($data['status']==1): ?> 显示 <?php else: ?> 不显示 <?php endif; ?></td>
                                <td><?php echo e($data['last_update_time']); ?></td>
                                <td><?php echo e($data['created_at']); ?></td>
                                <td class="td-manage">
                                    <a title="编辑" href="javascript:editmanhua(<?php echo e($data['manhua_id']); ?>)" class="ml-5"
                                       style="text-decoration:none">
                                        <i class="Hui-iconfont">&#xe6df;</i>

                                </td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <div class="ml-12" style="text-align: center;">
                    <?php echo e($datas->links()); ?>

                </div>


            </article>
        </div>

        <hr />

    </section>
    <script>

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>