<?php $__env->startSection("content"); ?>
    <script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/user.js?ver=1.0"); ?>"></script>
    <section class="Hui-article-box">
        <div class="Hui-article">
            <input type="hidden" id="hid_tid" value="0" />
            <article class="cl pd-20">
                <div class="text-c">
                    <form id="frm_admin" action="/backend/user/list" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <input type="text" class="input-text" style="width:250px" placeholder="输入会员名" id="seach_uname" name="searchword" value="">
                        <button type="submit" class="btn btn-success radius" id="btn_seach" name="btn_seach">
                            <i class="Hui-iconfont">&#xe665;</i> 搜
                        </button>
                    </form>
                </div>

                <div class="mt-20">
                    <table class="table table-border table-bordered table-hover table-bg table-sort">
                        <thead>
                        <tr class="text-c">
                            <th width="40">用户ID</th>
                            <th width="50">用户名</th>
                            <th width="50">代理ID</th>
                            <th width="30">VIP</th>
                            <th width="100">VIP过期时间</th>
                            <th width="50">金币余额</th>
                            <th width="30">status</th>
                            <th width="70">注册IP</th>
                            <th width="70">最近登陆IP</th>
                            <th width="100">最近登陆时间</th>
                            <th width="100">操作</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($datas as $data): ?>
                            <tr class="text-c">
                                <td><?php echo e($data['uid']); ?></td>
                                <td><a href="#<?php echo e($data['uid']); ?>" title="查询用户<?php echo e($data['user_name']); ?>的充值订单" style="color: red;"><?php echo e($data['user_name']); ?></a></td>
                                <td><?php echo e($data['daili_id']); ?></td>
                                <td><?php if($data['vip']==1): ?>VIP <?php else: ?> 普通会员 <?php endif; ?></td>
                                <td><?php echo e($data['vip_end_time']); ?></td>
                                <td><?php echo e($data['coin']); ?></td>
                                <td>
                                    <input type="button" onclick="changestatus('<?php echo e($data['status']); ?>','<?php echo e($data['uid']); ?>');" class="btn btn-<?php if($data['status'] ==0): ?>warning <?php elseif($data['status'] ==1): ?>primary <?php endif; ?> radius" value="<?php if($data['status'] ==1): ?>正常 <?php else: ?> 已冻结 <?php endif; ?>"  />
                                </td>
                                <td><?php echo e($data['register_ip']); ?></td>
                                <td><?php echo e($data['login_ip']); ?></td>
                                <td><?php echo e($data['last_login_time']); ?></td>
                                <td class="td-manage">
                                    <input type="button" onclick="changepwd('<?php echo e($data['uid']); ?>','<?php echo e($data['user_name']); ?>');" class="btn btn-primary  radius" value="修改密码 ">
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <div class="ml-12" style="text-align: center;">
                    <?php echo e($datas->links()); ?>

                </div>


            </article>
        </div>

        <hr />

    </section>
    <script>

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>