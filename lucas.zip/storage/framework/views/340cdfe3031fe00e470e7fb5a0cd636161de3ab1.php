<?php $__env->startSection("content"); ?>
    <script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/girls.js?ver=1.0"); ?>"></script>
    <section class="Hui-article-box">
        <div class="Hui-article">
            <input type="hidden" id="hid_tid" value="0" />
            <article class="cl pd-20">
                <div class="text-c">
                    <form id="frm_admin" action="/backend/girls/girllist" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <input type="text" class="input-text" style="width:250px" placeholder="输入名字" id="seach_uname" name="searchword" value="<?php echo e(isset($searchData['searchword'])?$searchData['searchword']:''); ?>">
                        <select name="area_id"  class="input-text" style="width:100px">
                            <option value="0">全部</option>
                            <?php foreach($areas as $area): ?>
                                <option value="<?php echo e($area['id']); ?>" <?php if(isset($searchData['area_id']) and $searchData['area_id']==$area['id']): ?>selected="selected"<?php endif; ?>><?php echo e($area['area_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-success radius" id="btn_seach" name="btn_seach">
                            <i class="Hui-iconfont">&#xe665;</i> 搜
                        </button>
                    </form>
                </div>

                <div class="cl pd-5 bg-1 bk-gray mt-20">
                <span class="l">
                    <a href="javascript:;" id="btn_add_category" class="btn btn-primary radius" onclick="opennewgirl();">
                        <i class="Hui-iconfont">&#xe600;</i> 添加美女
                    </a>
                </span>
                </div>

                <div class="mt-20">
                    <table class="table table-border table-bordered table-hover table-bg table-sort">
                        <thead>
                        <tr class="text-c">
                            <th width="40">ID</th>
                            <th width="50">标题</th>
                            <th width="60">封面</th>
                            <th width="50">名字</th>
                            <th width="90">下架时间</th>
                            <th width="80">年龄</th>
                            <th width="80">身高</th>
                            <th width="80">胸围</th>
                            <th width="80">体重</th>
                            <th width="80">Room</th>
                            <th width="80">Area</th>
                            <th width="80">地点</th>
                            <th width="80">价格</th>
                            <th width="80">电话</th>
                            <th width="80">微信</th>
                            <th width="80">状态</th>
                            <th width="80">Note</th>
                            <th width="80">视频列表</th>
                            <th width="80">服务列表</th>
                            <th width="50">浏览次数</th>
                            <th width="50">入库时间</th>
                            <th width="50">操作</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($datas as $data): ?>
                            <tr class="text-c">
                                <td><?php echo e($data['id']); ?></td>
                                <td><a style="color: green;" href="/backend/girls/girlphotolist/<?php echo e($data['id']); ?>"><?php echo e($data['title']); ?></a></td>
                                <td><a href="<?php echo e($data['cover']); ?>" target="_blank"><img src="<?php echo e($data['cover']); ?>" style="width:50px;" /></a></td>
                                <td><?php echo e($data['name']); ?></td>
                                <td><?php if(date("Ymd",strtotime($data['expire_date'])) >= date("Ymd")): ?> <?php echo e($data['expire_date']); ?> <?php else: ?> <em style="color: red;">已下架</em> <?php endif; ?></td>
                                <td><?php echo e($data['age']); ?></td>
                                <td><?php echo e($data['height']); ?></td>
                                <td><?php echo e($data['boobs']); ?></td>
                                <td><?php echo e($data['weight']); ?></td>
                                <td><?php echo e($data['room']); ?></td>
                                <td><?php echo e($data['area']); ?></td>
                                <td><?php echo e($data['area_name']); ?></td>
                                <td><?php echo e($data['price']); ?></td>
                                <td><?php echo e($data['mobile']); ?></td>
                                <td><?php echo e($data['wechat']); ?></td>
                                <td><?php echo e($data['show']==1?'显示':'隐藏'); ?></td>
                                <td><?php echo e($data['note']); ?></td>
                                <td><?php echo e($data['videolist']); ?></td>
                                <td><?php echo e($data['service']); ?></td>
                                <td><?php echo e($data['views']); ?></td>
                                <td><?php echo e($data['created_at']); ?></td>
                                <td class="td-manage">
                                    <a title="编辑" href="javascript:girledit(<?php echo e($data['id']); ?>)" class="ml-5"
                                       style="text-decoration:none">
                                        <i class="Hui-iconfont">&#xe6df;</i>
                                    </a>
                                    <?php if($data['status']!=9): ?>
                                    <a title="删除" href="javascript:girldel('<?php echo e($data['id']); ?>')" class="ml-5"
                                       style="text-decoration:none">
                                        <i class="Hui-iconfont">&#xe6e2;</i>
                                    </a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <div class="ml-12" style="text-align: center;">
                    <?php echo e($datas->links()); ?>

                </div>


            </article>
        </div>

        <hr />

    </section>
    <script>

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>