<?php $__env->startSection("content"); ?>
    <script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/withdraw.js?ver=1.0"); ?>"></script>
    <section class="Hui-article-box">
        <div class="Hui-article">
            <input type="hidden" id="hid_tid" value="0" />
            <article class="cl pd-20">
                <div class="text-c">
                    <form id="frm_admin" action="/backend/money/applywithdrawlist" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <input type="text" class="input-text" style="width:250px" placeholder="输入代理名" id="seach_uname" name="searchword" value="">
                        <button type="submit" class="btn btn-success radius" id="btn_seach" name="btn_seach">
                            <i class="Hui-iconfont">&#xe665;</i> 搜
                        </button>
                    </form>
                </div>

                <div class="mt-20">
                    <table class="table table-border table-bordered table-hover table-bg table-sort">
                        <thead>
                        <tr class="text-c">
                            <th width="50">提款ID号</th>
                            <th width="50">代理名</th>
                            <th width="50">订单号</th>
                            <th width="50">金额</th>
                            <th width="50">提款信息</th>
                            <th width="50">订单状态</th>
                            <th width="50">交易号</th>
                            <th width="50">备注</th>
                            <th width="50">处理时间</th>
                            <th width="50">创建时间</th>
                            <th width="100">操作</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($orders as $data): ?>
                            <tr class="text-c">
                                <td><?php echo e($data['withdraw_id']); ?></td>
                                <td><?php echo e($data['daili_name']); ?></td>
                                <td><?php echo e($data['order_no']); ?></td>
                                <td><?php echo e($data['withdraw_money']); ?></td>
                                <td><?php echo e($data['withdraw_info']); ?></td>
                                <td><?php if($data['status']==0): ?> 等待付款 <?php elseif($data['status']==1): ?> 已付款 <?php elseif($data['status']==2): ?> 已关闭 <?php elseif($data['status']==3): ?> 已取消 <?php endif; ?></td>
                                <td><?php echo e($data['transfer_no']); ?></td>
                                <td><?php echo e($data['remark']); ?></td>
                                <td><?php echo e($data['deal_time']); ?></td>
                                <td><?php echo e($data['created_at']); ?></td>
                                <td>&nbsp;
                                    <?php if($data['status']==0): ?>
                                        <input type="button" onclick="comfirmorder(<?php echo e($data['withdraw_id']); ?>)" class="btn btn-primary  radius" value="确认支付">
                                        <input type="button" onclick="closeorder(<?php echo e($data['withdraw_id']); ?>)" class="btn btn-primary  radius" value="关闭订单">
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <div class="ml-12" style="text-align: center;">
                    <?php echo e($orders->links()); ?>

                </div>


            </article>
        </div>

        <hr />

    </section>
    <script>

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>