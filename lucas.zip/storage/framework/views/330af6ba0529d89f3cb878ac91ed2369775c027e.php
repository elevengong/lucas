<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />

    <link href="<?php echo asset( "/resources/views/backend/static/h-ui/css/H-ui.min.css") ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset( "/resources/views/backend/static/h-ui.admin/css/H-ui.login.css") ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset( "/resources/views/backend/static/h-ui.admin/css/style.css") ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo asset( "/resources/views/backend/static/Hui-iconfont/1.0.8/iconfont.css") ?>" rel="stylesheet" type="text/css" />

    <title>添加分类</title>
    <meta name="keywords" content="添加分类">
    <meta name="description" content="添加分类">
</head>
<body>
<script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/jquery.min.1.9.1.js") ?>"></script>
<script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/My97DatePicker/4.8/WdatePicker.js"); ?>"></script>
<script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/layer/layer.js") ?>"></script>

<script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/daili.js?ver=1.0"); ?>"></script>
<div id="frm_account" class="col-xs-12" style="text-align: center;">
    <form class="form form-horizontal" id="form1">
        <?php echo e(csrf_field()); ?>

        <div class="col-xs-12 row cl">
            <label class="form-label col-xs-3 col-sm-3">代理名称：</label>
            <div class="col-xs-9 col-sm-9">
                <input type="text" class="input-text" value="" id="daili_name" name="daili_name" />
            </div>
        </div>
        <div class="col-xs-12 row cl">
            <label class="form-label col-xs-3 col-sm-3">代理密码：</label>
            <div class="col-xs-9 col-sm-9">
                <input type="password" class="input-text" value="" id="pwd" name="pwd" />
            </div>
        </div>
        <div class="col-xs-12 row cl">
            <label class="form-label col-xs-3 col-sm-3">状态：</label>
            <div class="col-xs-9 col-sm-9">
                <select name="status" style="float:left;" id="status">
                    <option value="1" selected="selected">启用</option>
                    <option value="0">冻结</option>
                </select>
            </div>
        </div>
        <div class="col-xs-12 row cl">
            <label class="form-label col-xs-3 col-sm-3">佣金比例：</label>
            <div class="col-xs-9 col-sm-9">
                <input type="text" class="input-text" value="0.70" id="commission_rate" name="commission_rate" />
            </div>
        </div>

        <div class="col-xs-12 row cl" style="text-align: center;">
            <div class="formControls col-xs-12 col-sm-12">
                <input type="button" onclick="adddailiprocess()" class="btn btn-primary" value="新增代理" id="btn_add_ok" />
            </div>
        </div>

    </form>
</div>

<script>
    function adddailiprocess() {
        var daili_name  = $.trim( $('#daili_name').val() );
        var pwd  = $.trim( $('#pwd').val() );
        var commission_rate = $.trim( $('#commission_rate').val() );
        var status  = $.trim( $('#status').val() );

        if(daili_name == '')
        {
            layer.msg('代理名称不能为空');
            return false;
        }
        if(pwd == '')
        {
            layer.msg('密码不能为空');
            return false;
        }
        if( $.inArray(status, ['0', '1']) == -1){
            layer.msg("状态异常");
            return false;
        }
        if(commission_rate > 1)
        {
            layer.msg("佣金比例不正确");
            return false;
        }
        $.ajax({
            type:"post",
            url:"/backend/daili/adddaili",
            dataType:'json',
            headers:{'X-CSRF-TOKEN':$('input[name="_token"]').val()},
            data:$("#form1").serialize(),
            success:function(data){
                if(data.status == 0)
                {
                    layer.msg( data.msg );
                }else{
                    layer.msg( data.msg ,function () {
                        window.parent.location.reload();
                        window.location.close();
                    });
                }
            },
            error:function (data) {
                layer.msg(data.msg);
            }
        });
    }
</script>



</body>
</html>
