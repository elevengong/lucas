<?php foreach($chpaterPhotos as $photo): ?>
    <div style="width: 800px;">
        <div style="width:500px;float: left;">
            <img src="/public/manhua/<?php echo e($photo['photo']); ?>" width="500px;" />
        </div>
        <div style="width:100px;float: left;">
            排列：<?php echo e($photo['priority']); ?>

        </div>
    </div>

<?php endforeach; ?>