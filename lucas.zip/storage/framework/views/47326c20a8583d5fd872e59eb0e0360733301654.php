<?php $__env->startSection("content"); ?>
    <script type="text/javascript" src="<?php echo asset( "/resources/views/backend/js/include/girls.js?ver=1.0"); ?>"></script>
    <section class="Hui-article-box">
        <div class="Hui-article">
            <input type="hidden" id="hid_tid" value="0" />
            <article class="cl pd-20">
                <div class="text-c">
                    <form id="frm_admin" action="/backend/girls/girllist" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <input type="text" class="input-text" style="width:250px" placeholder="输入名字" id="seach_uname" name="searchword" value="<?php echo e(isset($searchData['searchword'])?$searchData['searchword']:''); ?>">
                        <select name="status"  class="input-text" style="width:100px">
                            <option value="" <?php if(!isset($searchData['status']) or $searchData['status']==''): ?>selected="selected"<?php endif; ?>>Available</option>
                            <option value="0" <?php if(isset($searchData['status']) and $searchData['status']=='0'): ?>selected="selected"<?php endif; ?>>有空</option>
                            <option value="1" <?php if(isset($searchData['status']) and $searchData['status']=='1'): ?>selected="selected"<?php endif; ?>>在上钟</option>
                            <option value="2" <?php if(isset($searchData['status']) and $searchData['status']=='2'): ?>selected="selected"<?php endif; ?>>休息</option>
                            <option value="3" <?php if(isset($searchData['status']) and $searchData['status']=='3'): ?>selected="selected"<?php endif; ?>>下架</option>
                            <option value="9" <?php if(isset($searchData['status']) and $searchData['status']=='9'): ?>selected="selected"<?php endif; ?>>已删除</option>
                        </select>
                        <button type="submit" class="btn btn-success radius" id="btn_seach" name="btn_seach">
                            <i class="Hui-iconfont">&#xe665;</i> 搜
                        </button>
                    </form>
                </div>

                <div class="cl pd-5 bg-1 bk-gray mt-20">
                <span class="l">
                    <a href="javascript:;" id="btn_add_category" class="btn btn-primary radius" onclick="opennewgirl();">
                        <i class="Hui-iconfont">&#xe600;</i> 添加贵妃
                    </a>
                </span>
                </div>

                <div class="mt-20">
                    <table class="table table-border table-bordered table-hover table-bg table-sort">
                        <thead>
                        <tr class="text-c">
                            <th width="20">ID</th>
                            <th width="50">名字</th>
                            <th width="60">封面</th>
                            <th width="50">国籍</th>
                            <th width="80">介绍</th>
                            <th width="80">服务</th>
                            <th width="80">视频地址</th>
                            <th width="50">浏览次数</th>
                            <th width="50">状态</th>
                            <th width="50">更新时间</th>
                            <th width="50">入库时间</th>
                            <th width="50">操作</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach($datas as $data): ?>
                            <tr class="text-c">
                                <td><?php echo e($data['id']); ?></td>
                                <td><a style="color: green;" href="/backend/girls/girlphotolist/<?php echo e($data['id']); ?>"><?php echo e($data['name']); ?></a></td>
                                <td><a href="<?php echo e($data['cover']); ?>" target="_blank"><img src="<?php echo e($data['cover']); ?>" style="width:50px;" /></a></td>
                                <td><?php echo e($data['nation']); ?> &nbsp;&nbsp;<img src="<?php echo e($data['flag']); ?>" style="width:20px;" /></td>
                                <td><?php echo e($data['intro']); ?></td>
                                <td><?php echo e($data['service']); ?></td>
                                <td><?php echo e($data['videolist']); ?></td>
                                <td><?php echo e($data['views']); ?></td>
                                <td><?php echo e($status[$data['status']]); ?></td>
                                <td><?php echo e($data['updated_at']); ?></td>
                                <td><?php echo e($data['created_at']); ?></td>
                                <td class="td-manage">
                                    <a title="编辑" href="javascript:girledit(<?php echo e($data['id']); ?>)" class="ml-5"
                                       style="text-decoration:none">
                                        <i class="Hui-iconfont">&#xe6df;</i>
                                    </a>
                                    <?php if($data['status']!=9): ?>
                                    <a title="删除" href="javascript:girldel('<?php echo e($data['id']); ?>')" class="ml-5"
                                       style="text-decoration:none">
                                        <i class="Hui-iconfont">&#xe6e2;</i>
                                    </a>
                                        <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </div>

                <div class="ml-12" style="text-align: center;">
                    <?php echo e($datas->links()); ?>

                </div>


            </article>
        </div>

        <hr />

    </section>
    <script>

    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("backend.layout.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>