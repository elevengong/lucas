<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8">
    <title><?php echo e($base['title']); ?></title>
    <meta name="keywords" content="<?php echo $base['keywords']; ?>" />
    <meta name="description" content="<?php echo $base['description']; ?>" />
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height"/>
    <link href="<?php echo asset( "/resources/views/frontend/images/favicon.ico?ver=1.0") ?>" rel="shortcut icon" />
    <link rel="stylesheet" href="<?php echo asset( "/resources/views/frontend/css/css.css?ver=1.0") ?>">
    <script src="<?php echo asset( "/resources/views/frontend/js/jquery.min.js?ver=1.0") ?>"></script>
    <script src="<?php echo asset( "/resources/views/frontend/js/layer/layer.js") ?>"></script>
    <script src="<?php echo asset( "/resources/views/frontend/js/clipboard.min.js") ?>"></script>
</head>
<style>


</style>
<body>
<div class="header">
    <div class="logo wrap">
        <h1><a href="/"><?php echo e(isset($base['web_nickname'])?$base['web_nickname']:'LL'); ?></a></h1>

    </div>
    <div class="search wrap">
        <div class="searchbox">
            <form method="post" action="/search.html">
                <?php echo e(csrf_field()); ?>

                <input type="text" name="key" id="key" placeholder="输入关键词" value="<?php echo e(isset($keyword)?$keyword:''); ?>"><button>SEARCH</button>
            </form>
        </div>

        <?php if(empty($username)): ?>
        <div class="memberbox" style=""><a href="/login.html"><button>登陆</button></a><a href="/register.html"><button>注册</button></a></div>
            <?php else: ?>

            <div class="memberbox">
                <ul style="margin-top: 6px;">
                    <li class="reg_share">
                        <span>用户:<a href="/user/center.html"><?php echo e($username); ?></a></span>
                    </li>
                    <li class="reg_share">
                        <span>新币:<a href="#"><?php echo e($coin); ?>个</a></span>
                    </li>
                    <li class="reg_share">
                    <button type="button" class="btn copyagentlink" data-clipboard-text="<?php echo e($base['domain']); ?>/agent/<?php echo e($uid); ?>" style="width:125px;height:25px;font-size:14px;border-radius:3px;">点击复制推广链接</button>
                    </li>

                    <li class="reg_share">
                        <span><a href="/user/logout" style="color: red;">注销</a></span>
                    </li>



                </ul>
            </div>

        <?php endif; ?>
    </div>
    <div class="nav wrap">
        <ul>
            <li><a href="/" ><font color="black">MainPage/主页</font></a></li>
            <?php foreach($category as $ca): ?>
            <li><a href="/category/<?php echo e($ca['id']); ?>.html" ><font color="black"><?php echo e($ca['area_name']); ?></font></a></li>
            <?php endforeach; ?>
            <li><a href="/category/1000.html"><font color="black">Massage/按摩</font></a></li>
            <li><a href="/category/1001.html"><font color="black">Video/视频</font></a></li>

        </ul>
    </div>

</div>
<?php echo $__env->yieldContent('content'); ?>
<div class="footer wrap"><?php echo $base['copyright']; ?></div>
<div style="display: none;">
    <!-- 统计 -->
</div>
<script>
    $(function() {
        var clipboardlink = new Clipboard('.copyagentlink');
        clipboardlink.on('success', function(e) {
            layer.msg('推广链接复制成功，请发送给好友注册获取新币');
        });
        clipboardlink.on('error', function(e) {
            layer.msg('推广链接复制失败');
        });
    });
</script>
</body>
</html>
