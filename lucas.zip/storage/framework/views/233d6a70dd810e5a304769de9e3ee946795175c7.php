<?php $__env->startSection('content'); ?>

    <div class="wrap">
        <div class="index-rbox">
            <div class="i-title"><h1>所有美女</h1></div>
            <div class="pics-box">
                <ul>
                    <?php foreach($girls as $girl): ?>
                        <li>
                            <a href="/model/<?php echo e($girl['id']); ?>.html" class="img"><img class="lazy" data-original="<?php echo e($girl['cover']); ?>"></a>
                            <p><em><?php echo e($girl['name']); ?></em></p>
                            <p>身高：<?php echo e($girl['height']); ?>/罩杯：<?php echo e($girl['boobs']); ?></p>
                            <p><?php echo e($girl['price']); ?></p>
                            <?php if(!empty(trim($girl['videolist']))): ?><span class="video"></span><?php endif; ?>
                            <?php if($girl['massage']==2): ?><span class="mass"></span><?php endif; ?>
                            <?php if($girl['threesome']==2): ?><span class="p3"></span><?php endif; ?>
                        <!-- 如果后台添加时间在7天以内，当做新货-->
                            <?php if(date("Ymd",strtotime($girl['created_at']))+6 >= date("Ymd")): ?><span class="new">NEW　新货　<?php echo e(date("Y/m/d",strtotime($girl['created_at']))); ?></span><?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="index-lbox">
            <div class="new_title"><h1>最近更新</h1></div>
            <div class="pics-box">
                <ul>
                    <?php foreach($leftList as $list): ?>
                    <li>
                        <a href="/model/<?php echo e($list['id']); ?>.html" class="img"><img src="<?php echo e($list['cover']); ?>"></a>
                        <p><em><?php echo e($list['name']); ?></em></p>
                        <p>身高：<?php echo e($list['height']); ?>/罩杯：<?php echo e($list['boobs']); ?></p>
                        <p><?php echo e($list['price']); ?></p>
                        <?php if(!empty(trim($list['videolist']))): ?><span class="video"></span><?php endif; ?>
                        <?php if($list['massage']==2): ?><span class="mass"></span><?php endif; ?>
                        <?php if($list['threesome']==2): ?><span class="p3"></span><?php endif; ?>
                        <?php if(date("Ymd",strtotime($list['created_at']))+6 >= date("Ymd")): ?><span class="new">NEW　新货　<?php echo e(date("Y/m/d",strtotime($list['created_at']))); ?></span><?php endif; ?>

                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>





    </div>
    <script src="<?php echo asset( "/resources/views/frontend/js/jquery-1.11.0.min.js") ?>"></script>
    <script src="<?php echo asset( "/resources/views/frontend/js/jquery.lazyload.js") ?>"></script>
    <script type="text/javascript" charset="utf-8">

        function lazyload(){
            $("img.lazy").lazyload({
                placeholder : "/resources/views/frontend/images/loading.png",
                effect: "fadeIn",
            });
        }
        lazyload();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>