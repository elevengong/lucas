<?php

namespace App\Http\Controllers\frontend;

use App\Model\Girls;
use App\Model\Girlphotos;
use App\Model\Attribute;
use App\Model\Members;

use Illuminate\Http\Request;
use App\Http\Controllers\MyController;
use App\Http\Requests;

class UserController extends MyController{










}