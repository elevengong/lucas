<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;

class IndexController extends Controller
{
    public function index(){
        return "http://img.ksbbs.com/asset/Mon_1703/05cacb4e02f9d9e.mp4";
    }

}
